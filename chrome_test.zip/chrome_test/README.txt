This is a security test file. For testing purposes only.
Symlink points to: /Users/sean/Library/Application Support/Google/Chrome/Profile 27/History
Created: $(date)
